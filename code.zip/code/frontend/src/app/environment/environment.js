export const env = {
    url:'http://localhost:8006/'
}

